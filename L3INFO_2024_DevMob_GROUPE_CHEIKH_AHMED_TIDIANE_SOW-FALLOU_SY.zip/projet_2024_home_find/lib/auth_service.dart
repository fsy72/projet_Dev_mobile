class AuthService {
  // Stream pour écouter les changements d'état de l'utilisateur (à adapter si nécessaire)
  Stream<dynamic> get userStream => Stream.empty(); // Remplacez par votre logique si nécessaire

  // Connexion avec Google (désactivée)
  Future<dynamic> signInWithGoogle() async {
    throw Exception("L'authentification Google n'est pas implémentée.");
  }

  // Connexion avec Facebook (désactivée)
  Future<dynamic> signInWithFacebook() async {
    throw Exception("L'authentification Facebook n'est pas implémentée.");
  }

  // Inscription avec email/mot de passe (désactivée)
 /* Future<dynamic> signUpWithEmailAndPassword(String email, String password) async {
    throw Exception("L'inscription par email/mot de passe n'est pas implémentée.");
  }

  // Connexion avec email/mot de passe (désactivée)
  Future<dynamic> signInWithEmailAndPassword(String email, String password) async {
    throw Exception("La connexion par email/mot de passe n'est pas implémentée.");
  }

  // Déconnexion (désactivée)
  Future<void> signOut() async {
    throw Exception("La déconnexion n'est pas implémentée.");
  }*/
}