import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Pour Firestore
import 'package:firebase_auth/firebase_auth.dart'; // Pour la déconnexion
import 'profile_page.dart'; // Importe la page de profil
import 'publication_detail_page.dart'; // Importe la page de détails de la publication
import 'favorites_page.dart'; // Importe la page des favoris
import 'search_page.dart'; // Importe la page de recherche
import 'login_page.dart'; // Importe la page de login

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  int _selectedIndex = 0; // Index de l'onglet sélectionné
  final PageController _pageController = PageController(); // Contrôleur pour la navigation

  // Liste des pages
  final List<Widget> _pages = [
    HomeContentPage(), // Page d'accueil (contenu actuel de HomePage)
    SearchPage(), // Page de recherche
    FavoritesPage(), // Page des favoris
    ProfilePage(), // Page de profil
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        elevation: 0,
        title: Text(
          'HomeFind',
          style: TextStyle(
            color: const Color.fromARGB(255, 224, 138, 7),
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.menu, color: Colors.white),
            onPressed: () {
              Scaffold.of(context).openDrawer(); // Ouvre le menu latéral
            },
          ),
        ],
      ),
      drawer: _buildDrawer(), // Ajoute le menu latéral
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Color.fromARGB(255, 224, 138, 7),
        unselectedItemColor: Colors.grey[500],
        backgroundColor: Colors.grey[900],
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
            _pageController.jumpToPage(index);
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Accueil',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Recherche',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: 'Favoris',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }

  // Fonction pour construire le menu latéral
  Widget _buildDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.grey[900],
            ),
            child: Text(
              'Menu',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.settings, color: Colors.grey[700]),
            title: Text('Paramètres'),
            onTap: () {
              // Naviguer vers la page des paramètres
              Navigator.pop(context); // Ferme le menu
            },
          ),
          ListTile(
            leading: Icon(Icons.help, color: Colors.grey[700]),
            title: Text('Aide'),
            onTap: () {
              // Naviguer vers la page d'aide
              Navigator.pop(context); // Ferme le menu
            },
          ),
          ListTile(
            leading: Icon(Icons.logout, color: Colors.grey[700]),
            title: Text('Déconnexion'),
            onTap: () async {
              // Déconnexion de l'utilisateur
              await FirebaseAuth.instance.signOut();
              // Rediriger vers la page de login
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => LoginPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}

// Page d'accueil (contenu actuel de HomePage)
class HomeContentPage extends StatefulWidget {
  const HomeContentPage({super.key});

  @override
  State<HomeContentPage> createState() => _HomeContentPageState();
}

class _HomeContentPageState extends State<HomeContentPage> {
  // Simulations de publication
  final List<Map<String, dynamic>> logements = [
    {
      "title": "Studio étudiant + salle de bain",
      "location": "Sanar Peuhl",
      "price": "30 000f/mois",
      "rating": 4.5,
      "image": "assets/images/studio.jpg",
      "description":
          "Un studio étudiant moderne avec salle de bain privée, idéal pour les étudiants. Proche des universités et des commodités.",
      "additionalImages": [
        "assets/images/studio1.jpg",
        "assets/images/studio2.jpg",
        "assets/images/studio3.jpg",
      ],
    },
    {
      "title": "Appartement moderne avec terrasse",
      "location": "Dakar Fleurus",
      "price": "150 000f/mois",
      "rating": 4.8,
      "image": "assets/images/appartement.jpg",
      "description":
          "Un appartement spacieux avec une grande terrasse offrant une vue imprenable sur la ville. Parfait pour les familles.",
      "additionalImages": [
        "assets/images/appartement1.jpg",
        "assets/images/appartement2.jpg",
        "assets/images/appartement3.jpg",
      ],
    },
    {
      "title": "Maison spacieuse proche de la plage",
      "location": "Saint Louis",
      "price": "250 000f/mois",
      "rating": 4.7,
      "image": "assets/images/maison.jpg",
      "description":
          "Une maison spacieuse située à quelques pas de la plage. Idéale pour les vacances ou une résidence permanente.",
      "additionalImages": [
        "assets/images/maison1.jpg",
        "assets/images/maison2.jpg",
        "assets/images/maison3.jpg",
      ],
    },
  ];

  final List<String> filters = [
    "Tous les types",
    "Appartements",
    "Maisons",
    "Studios"
  ];

  int selectedFilterIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Barre de recherche
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Rechercher un logement...',
              hintStyle: TextStyle(color: Colors.grey[400]),
              prefixIcon: Icon(Icons.search, color: Colors.grey[400]),
              filled: true,
              fillColor: Colors.grey[800],
              contentPadding: EdgeInsets.symmetric(vertical: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),

        // Filtres horizontaux
        Container(
          height: 50,
          margin: const EdgeInsets.only(left: 16, bottom: 10),
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: filters.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 10.0),
                child: ChoiceChip(
                  label: Text(filters[index]),
                  selected: selectedFilterIndex == index,
                  onSelected: (selected) {
                    setState(() {
                      selectedFilterIndex = index;
                    });
                  },
                  selectedColor: const Color.fromARGB(255, 223, 137, 10),
                  backgroundColor: Colors.grey[700],
                  labelStyle: TextStyle(
                    color: selectedFilterIndex == index
                        ? Colors.white
                        : Colors.grey[400],
                  ),
                ),
              );
            },
          ),
        ),

        // Liste des logements (simulations + annonces des utilisateurs)
        Expanded(
          child: ListView(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            children: [
              // Simulations de publication
              ...logements.map((logement) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PublicationDetailPage(
                          publication: logement,
                        ),
                      ),
                    );
                  },
                  child: Card(
                    margin: EdgeInsets.only(bottom: 16.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Image de la carte
                        ClipRRect(
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(15),
                          ),
                          child: Image.asset(
                            logement['image'],
                            height: 200,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),

                        // Informations sur le logement
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                logement['title'],
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(height: 8),
                              Text(
                                logement['location'],
                                style: TextStyle(color: Colors.grey[400]),
                              ),
                              SizedBox(height: 8),
                              Text(
                                logement['price'],
                                style: TextStyle(
                                  fontSize: 16,
                                  color: const Color.fromARGB(255, 235, 146, 14),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 8),
                              Row(
                                children: [
                                  Icon(Icons.star, color: Colors.yellow[600], size: 18),
                                  SizedBox(width: 4),
                                  Text(
                                    logement['rating'].toString(),
                                    style: TextStyle(color: Colors.white),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),

              // Annonces des utilisateurs
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('ads')
                    .orderBy('timestamp', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }

                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return SizedBox(); // Affiche rien si aucune annonce n'est disponible
                  }

                  final ads = snapshot.data!.docs;

                  return Column(
                    children: ads.map((ad) {
                      final adData = ad.data() as Map<String, dynamic>;
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => PublicationDetailPage(
                                publication: adData,
                              ),
                            ),
                          );
                        },
                        child: Card(
                          margin: EdgeInsets.only(bottom: 16.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Image de la carte
                              ClipRRect(
                                borderRadius: BorderRadius.vertical(
                                  top: Radius.circular(15),
                                ),
                                child: Image.network(
                                  adData['images'][0],
                                  height: 200,
                                  width: double.infinity,
                                  fit: BoxFit.cover,
                                ),
                              ),

                              // Informations sur le logement
                              Padding(
                                padding: const EdgeInsets.all(16.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      adData['type'],
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      adData['location'],
                                      style: TextStyle(color: Colors.grey[400]),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      adData['price'],
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: const Color.fromARGB(255, 235, 146, 14),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      adData['description'],
                                      style: TextStyle(color: Colors.grey[400]),
                                    ),
                                    if (adData['phone'] != null) SizedBox(height: 8),
                                    if (adData['phone'] != null)
                                      Text(
                                        'Contact: ${adData['phone']}',
                                        style: TextStyle(color: Colors.grey[400]),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }
}