// import 'package:flutter/material.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';

// class PublishAdPage extends StatefulWidget {
//   @override
//   _PublishAdPageState createState() => _PublishAdPageState();
// }

// class _PublishAdPageState extends State<PublishAdPage> {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController _typeController = TextEditingController();
//   final TextEditingController _locationController = TextEditingController();
//   final TextEditingController _priceController = TextEditingController();
//   final TextEditingController _descriptionController = TextEditingController();
//   final TextEditingController _phoneController = TextEditingController();

//   List<File> _images = [];
//   final ImagePicker _picker = ImagePicker();
//   bool _isLoading = false;

//   Future<void> _pickImages() async {
//     final List<XFile>? pickedFiles = await _picker.pickMultiImage(maxWidth: 800, maxHeight: 800);
//     if (pickedFiles != null && pickedFiles.isNotEmpty) {
//       if (pickedFiles.length + _images.length > 4) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Vous ne pouvez sélectionner que 4 images maximum.')),
//         );
//         return;
//       }
//       setState(() {
//         _images.addAll(pickedFiles.map((file) => File(file.path)).toList());
//       });
//     }
//   }

//   Future<void> _publishAd() async {
//     if (_formKey.currentState!.validate() && _images.isNotEmpty) {
//       setState(() {
//         _isLoading = true;
//       });

//       try {
//         // Upload images to Firebase Storage
//         List<String> imageUrls = [];
//         for (var image in _images) {
//           final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
//           final Reference storageRef = FirebaseStorage.instance.ref().child('ads/$fileName');
//           await storageRef.putFile(image);
//           final String downloadUrl = await storageRef.getDownloadURL();
//           imageUrls.add(downloadUrl);
//         }

//         // Save ad data to Firestore
//         await FirebaseFirestore.instance.collection('ads').add({
//           'type': _typeController.text,
//           'location': _locationController.text,
//           'price': _priceController.text,
//           'description': _descriptionController.text,
//           'phone': _phoneController.text,
//           'images': imageUrls,
//           'timestamp': FieldValue.serverTimestamp(),
//         });

//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Annonce publiée avec succès !')),
//         );

//         Navigator.pop(context); // Retour à la page précédente
//       } on FirebaseException catch (e) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Erreur Firebase : ${e.message}')),
//         );
//       } catch (e) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('Erreur inattendue : $e')),
//         );
//       } finally {
//         setState(() {
//           _isLoading = false;
//         });
//       }
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(content: Text('Veuillez remplir tous les champs et sélectionner au moins une image.')),
//       );
//     }
//   }

//   Widget _buildImageGrid() {
//     return GridView.builder(
//       shrinkWrap: true,
//       physics: NeverScrollableScrollPhysics(),
//       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//         crossAxisCount: 2,
//         crossAxisSpacing: 10,
//         mainAxisSpacing: 10,
//       ),
//       itemCount: _images.length,
//       itemBuilder: (context, index) {
//         return Stack(
//           children: [
//             Image.file(
//               _images[index],
//               fit: BoxFit.cover,
//             ),
//             Positioned(
//               top: 5,
//               right: 5,
//               child: IconButton(
//                 icon: Icon(Icons.close, color: Colors.red),
//                 onPressed: () {
//                   setState(() {
//                     _images.removeAt(index);
//                   });
//                 },
//               ),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Publier une annonce'),
//         backgroundColor: Colors.grey[900],
//       ),
//       body: SingleChildScrollView(
//         padding: EdgeInsets.all(16.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               TextFormField(
//                 controller: _typeController,
//                 decoration: InputDecoration(
//                   labelText: 'Type de localité (studio, maison, appartement)',
//                   filled: true,
//                   fillColor: Colors.grey[800],
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Veuillez entrer le type de localité.';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _locationController,
//                 decoration: InputDecoration(
//                   labelText: 'Localisation',
//                   filled: true,
//                   fillColor: Colors.grey[800],
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Veuillez entrer la localisation.';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _priceController,
//                 decoration: InputDecoration(
//                   labelText: 'Prix',
//                   filled: true,
//                   fillColor: Colors.grey[800],
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                 ),
//                 keyboardType: TextInputType.number,
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Veuillez entrer le prix.';
//                   }
//                   if (double.tryParse(value) == null) {
//                     return 'Veuillez entrer un nombre valide.';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _descriptionController,
//                 decoration: InputDecoration(
//                   labelText: 'Description',
//                   filled: true,
//                   fillColor: Colors.grey[800],
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                 ),
//                 maxLines: 3,
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Veuillez entrer une description.';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               TextFormField(
//                 controller: _phoneController,
//                 decoration: InputDecoration(
//                   labelText: 'Numéro de téléphone (optionnel)',
//                   filled: true,
//                   fillColor: Colors.grey[800],
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(8.0),
//                   ),
//                 ),
//                 keyboardType: TextInputType.phone,
//                 validator: (value) {
//                   if (value != null && value.isNotEmpty && !RegExp(r'^[0-9]{10}$').hasMatch(value)) {
//                     return 'Veuillez entrer un numéro de téléphone valide.';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: _pickImages,
//                 child: Text('Sélectionner des images (max 4)'),
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: Colors.orange,
//                   minimumSize: Size(double.infinity, 50),
//                 ),
//               ),
//               SizedBox(height: 20),
//               _images.isNotEmpty ? _buildImageGrid() : Container(),
//               SizedBox(height: 20),
//               _isLoading
//                   ? Center(child: CircularProgressIndicator())
//                   : ElevatedButton(
//                       onPressed: _publishAd,
//                       child: Text('Publier l\'annonce'),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.green,
//                         minimumSize: Size(double.infinity, 50),
//                       ),
//                     ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class PublishAdPage extends StatefulWidget {
  @override
  _PublishAdPageState createState() => _PublishAdPageState();
}

class _PublishAdPageState extends State<PublishAdPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _typeController = TextEditingController();
  final TextEditingController _locationController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  List<File> _images = [];
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  Future<void> _pickImages() async {
    final List<XFile>? pickedFiles = await _picker.pickMultiImage(maxWidth: 800, maxHeight: 800);
    if (pickedFiles != null && pickedFiles.isNotEmpty) {
      if (pickedFiles.length + _images.length > 4) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Vous ne pouvez sélectionner que 4 images maximum.')),
        );
        return;
      }
      setState(() {
        _images.addAll(pickedFiles.map((file) => File(file.path)).toList());
      });
    }
  }

  Future<void> _publishAd() async {
    if (_formKey.currentState!.validate() && _images.isNotEmpty) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Upload images to Firebase Storage
        List<String> imageUrls = [];
        for (var image in _images) {
          final String fileName = DateTime.now().millisecondsSinceEpoch.toString();
          final Reference storageRef = FirebaseStorage.instance.ref().child('ads/$fileName');
          await storageRef.putFile(image);
          final String downloadUrl = await storageRef.getDownloadURL();
          imageUrls.add(downloadUrl);
        }

        // Save ad data to Firestore
        await FirebaseFirestore.instance.collection('ads').add({
          'type': _typeController.text,
          'location': _locationController.text,
          'price': _priceController.text,
          'description': _descriptionController.text,
          'phone': _phoneController.text,
          'images': imageUrls,
          'timestamp': FieldValue.serverTimestamp(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Annonce publiée avec succès !')),
        );

        Navigator.pop(context); // Retour à la page précédente
      } on FirebaseException catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur Firebase : ${e.message}')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur inattendue : $e')),
        );
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Veuillez remplir tous les champs et sélectionner au moins une image.')),
      );
    }
  }

  Widget _buildImageGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
      ),
      itemCount: _images.length,
      itemBuilder: (context, index) {
        return Stack(
          children: [
            Image.file(
              _images[index],
              fit: BoxFit.cover,
            ),
            Positioned(
              top: 5,
              right: 5,
              child: IconButton(
                icon: Icon(Icons.close, color: Colors.red),
                onPressed: () {
                  setState(() {
                    _images.removeAt(index);
                  });
                },
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Publier une annonce'),
        backgroundColor: Colors.grey[900],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _typeController,
                decoration: InputDecoration(
                  labelText: 'Type de localité (studio, maison, appartement)',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer le type de localité.';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _locationController,
                decoration: InputDecoration(
                  labelText: 'Localisation',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer la localisation.';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _priceController,
                decoration: InputDecoration(
                  labelText: 'Prix',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer le prix.';
                  }
                  if (double.tryParse(value) == null) {
                    return 'Veuillez entrer un nombre valide.';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                maxLines: 3,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Veuillez entrer une description.';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _phoneController,
                decoration: InputDecoration(
                  labelText: 'Numéro de téléphone (optionnel)',
                  filled: true,
                  fillColor: Colors.grey[800],
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                keyboardType: TextInputType.phone,
                validator: (value) {
                  if (value != null && value.isNotEmpty && !RegExp(r'^[0-9]{10}$').hasMatch(value)) {
                    return 'Veuillez entrer un numéro de téléphone valide.';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _pickImages,
                child: Text('Sélectionner des images (max 4)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  minimumSize: Size(double.infinity, 50),
                ),
              ),
              SizedBox(height: 20),
              _images.isNotEmpty ? _buildImageGrid() : Container(),
              SizedBox(height: 20),
              _isLoading
                  ? Center(child: CircularProgressIndicator())
                  : ElevatedButton(
                      onPressed: _publishAd,
                      child: Text('Publier l\'annonce'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        minimumSize: Size(double.infinity, 50),
                      ),
                    ),
            ],
          ),
        ),
      ),
    );
  }
}