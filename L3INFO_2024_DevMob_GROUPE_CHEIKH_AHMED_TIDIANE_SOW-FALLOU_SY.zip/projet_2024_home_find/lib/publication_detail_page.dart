import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; // Pour les actions SMS, WhatsApp et APPEL

class PublicationDetailPage extends StatelessWidget {
  final Map<String, dynamic> publication;

  PublicationDetailPage({required this.publication});

  // Fonction pour envoyer un SMS
  Future<void> _sendSMS() async {
    final Uri smsUri = Uri(
      scheme: 'sms',
      path: '771234567', // Remplace par le numéro de téléphone souhaité
      queryParameters: {
        'body': 'Bonjour, je suis intéressé par votre publication : ${publication['title']}',
      },
    );
    if (await canLaunchUrl(smsUri)) {
      await launchUrl(smsUri);
    } else {
      throw 'Impossible d\'envoyer un SMS.';
    }
  }

  // Fonction pour ouvrir WhatsApp
  Future<void> _openWhatsApp() async {
    final Uri whatsappUri = Uri(
      scheme: 'https',
      host: 'wa.me',
      path: '221771234567', // Remplace par le numéro de téléphone souhaité
      queryParameters: {
        'text': 'Bonjour, je suis intéressé par votre publication : ${publication['title']}',
      },
    );
    if (await canLaunchUrl(whatsappUri)) {
      await launchUrl(whatsappUri);
    } else {
      throw 'Impossible d\'ouvrir WhatsApp.';
    }
  }

  // Fonction pour passer un appel
  Future<void> _makeCall() async {
    final Uri callUri = Uri(
      scheme: 'tel',
      path: '221771234567', // Remplace par le numéro de téléphone souhaité
    );
    if (await canLaunchUrl(callUri)) {
      await launchUrl(callUri);
    } else {
      throw 'Impossible de passer un appel.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Détails de la publication'),
        backgroundColor: Colors.grey[900],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Image principale
                ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: Image.asset(
                    publication['image'],
                    width: double.infinity,
                    height: 200,
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(height: 20),

                // Titre
                Text(
                  publication['title'],
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 10),

                // Localisation
                Row(
                  children: [
                    Icon(Icons.location_on, color: Colors.grey[400], size: 18),
                    SizedBox(width: 5),
                    Text(
                      publication['location'],
                      style: TextStyle(color: Colors.grey[400]),
                    ),
                  ],
                ),
                SizedBox(height: 20),

                // Prix
                Text(
                  publication['price'],
                  style: TextStyle(
                    fontSize: 20,
                    color: const Color.fromARGB(255, 235, 146, 14),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 20),

                // Description
                Text(
                  "Description :",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  publication['description'],
                  style: TextStyle(color: Colors.grey[400]),
                ),
                SizedBox(height: 20),

                // Galerie d'images supplémentaires
                Text(
                  "Galerie d'images :",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 10),
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: publication['additionalImages'].length,
                  itemBuilder: (context, index) {
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.asset(
                        publication['additionalImages'][index],
                        fit: BoxFit.cover,
                      ),
                    );
                  },
                ),
                SizedBox(height: 80), // Espace pour les boutons flottants
              ],
            ),
          ),

          // Boutons flottants
          Positioned(
            bottom: 20,
            left: 20,
            right: 20,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                // Bouton SMS
                FloatingActionButton(
                  onPressed: _sendSMS,
                  backgroundColor: Colors.blue,
                  child: Icon(Icons.sms, color: Colors.white),
                ),

                // Bouton WhatsApp
                FloatingActionButton(
                  onPressed: _openWhatsApp,
                  backgroundColor: Colors.green,
                  child: Icon(Icons.message, color: Colors.white),
                ),

                // Bouton APPEL
                FloatingActionButton(
                  onPressed: _makeCall,
                  backgroundColor: Colors.red,
                  child: Icon(Icons.call, color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}