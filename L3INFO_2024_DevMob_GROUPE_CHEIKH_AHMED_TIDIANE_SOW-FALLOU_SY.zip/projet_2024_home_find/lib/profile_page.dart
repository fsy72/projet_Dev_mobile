import 'package:flutter/material.dart';
import 'publish_ad_page.dart'; // Importe la page de publication d'annonce

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profil'),
        backgroundColor: Colors.grey[900],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Section "Pro Suivi" avec dégradé
            GestureDetector(
              onTap: () {
                // Naviguer vers la page Pro
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProPage()),
                );
              },
              child: Container(
                padding: EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.orange, Colors.deepOrange],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    Icon(Icons.star, color: Colors.white, size: 24),
                    SizedBox(width: 8),
                    Text(
                      'Pro Suivi',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),

            // Informations de l'utilisateur avec dégradé
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.grey[800]!, Colors.grey[900]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Maissa Mbaye',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.grey[400], size: 18),
                      SizedBox(width: 5),
                      Text(
                        'Rao, St Louis, Sénégal',
                        style: TextStyle(color: Colors.grey[400]),
                      ),
                    ],
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Membre depuis 3 ans',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[400],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),

            // Section "Vendez plus vite" avec dégradé
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue[600]!, Colors.blue[900]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                'La confiance du clientele, notre préoccupation!',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 20),

            // Statistiques des annonces avec dégradé
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue[600]!, Colors.blue[900]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Annonces',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildStatistic('En vente', '2'),
                      _buildStatistic('Vendues', '0'),
                      _buildStatistic('Expirées', '0'),
                      _buildStatistic('Rejetées', '1'),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),

            // Section "Annonces récentes" avec dégradé
            Container(
              padding: EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.grey[800]!, const Color.fromARGB(255, 152, 153, 156)!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Annonces récentes',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10),
                  _buildAnnouncementCard(
                    title: 'Appartement Meublé, 2 chambres + Salon',
                    location: 'Ngor, Dakar, Sénégal',
                    price: '190,000 CFA',
                  ),
                  _buildAnnouncementCard(
                    title: 'Terrain 150 m², Titre Foncier',
                    location: 'Ngor, Dakar, Sénégal',
                    price: 'Prix sur demande',
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
      // Bouton flottant pour publier une annonce
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Naviguer vers la page de publication d'annonce
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PublishAdPage()),
          );
        },
        icon: Icon(Icons.mic, color: Colors.white), // Icône de haut-parleur
        label: Text(
          'Publier une annonce',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.orange, // Couleur du bouton
        elevation: 4.0, // Ombre du bouton
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat, // Position du bouton
    );
  }

  // Widget pour afficher une statistique
  Widget _buildStatistic(String label, String value) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[400],
          ),
        ),
      ],
    );
  }

  // Widget pour afficher une annonce
  Widget _buildAnnouncementCard({
    required String title,
    required String location,
    required String price,
  }) {
    return Card(
      margin: EdgeInsets.only(bottom: 16.0),
      color: Colors.grey[800],
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.location_on, color: Colors.grey[400], size: 16),
                SizedBox(width: 5),
                Text(
                  location,
                  style: TextStyle(color: Colors.grey[400]),
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              price,
              style: TextStyle(
                fontSize: 16,
                color: const Color.fromARGB(255, 235, 146, 14),
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Page Pro (à créer)
class ProPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Abonnement Pro'),
        backgroundColor: Colors.grey[900],
      ),
      body: Center(
        child: Text(
          'Page Pro - Fonctionnalités premium',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}