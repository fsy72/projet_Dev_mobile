package com.example.projet_2024_home_find

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
